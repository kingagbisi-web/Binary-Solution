#!/usr/bin/env bash
set -euo pipefail
echo 'Starting FX Binary Bot (Termux) setup...'
if [ ! -d venv ]; then
  python -m venv venv
fi
. venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
mkdir -p models
# start backend
nohup venv/bin/uvicorn app:app --host 0.0.0.0 --port 8000 &> uvicorn.log &
# start worker
nohup venv/bin/python worker_twelvedata.py &> worker.log &
echo 'Started backend and worker. Check uvicorn.log and worker.log for output.'
