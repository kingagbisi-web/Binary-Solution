from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
from datetime import datetime
import sqlite3, os, json
from dotenv import load_dotenv
import pandas as pd
load_dotenv()

DB = os.getenv('DATABASE_URL','sqlite:///./fxbot_termux.db').replace('sqlite:///','')
conn = sqlite3.connect(DB, check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS candles (id INTEGER PRIMARY KEY, pair TEXT, timeframe TEXT, ts TEXT, o REAL, h REAL, l REAL, c REAL, v REAL)''')
c.execute('''CREATE TABLE IF NOT EXISTS signals (id INTEGER PRIMARY KEY, pair TEXT, timeframe TEXT, ts TEXT, signal TEXT, confidence REAL, reasons TEXT, metadata TEXT, created_at TEXT)''')
conn.commit()

app = FastAPI(title='FX Binary Bot - Termux')

class CandleIn(BaseModel):
    pair: str; timeframe: str; ts: datetime; o: float; h: float; l: float; c: float; v: float = 0.0

def insert_candle(data: CandleIn):
    cur = conn.cursor()
    cur.execute('INSERT INTO candles (pair,timeframe,ts,o,h,l,c,v) VALUES (?,?,?,?,?,?,?,?)',
                (data.pair, data.timeframe, data.ts.isoformat(), data.o, data.h, data.l, data.c, data.v))
    conn.commit()

@app.post('/ingest/candle')
def ingest(candle: CandleIn, background_tasks: BackgroundTasks):
    try:
        insert_candle(candle)
        background_tasks.add_task(process_signals_for_pair, candle.pair, candle.timeframe)
        return {'status':'ok'}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def compute_signal_from_candles(df):
    import pandas as pd, numpy as np
    close = df['c']
    ema9 = close.ewm(span=9, adjust=False).mean()
    ema21 = close.ewm(span=21, adjust=False).mean()
    delta = close.diff()
    up = delta.clip(lower=0)
    down = -1*delta.clip(upper=0)
    ma_up = up.rolling(14).mean()
    ma_down = down.rolling(14).mean()
    rs = ma_up / (ma_down + 1e-9)
    rsi = 100 - (100/(1+rs))
    latest = -1
    score = 0.0; reasons=[]
    if ema9.iloc[latest] > ema21.iloc[latest]:
        score += 0.4; reasons.append('EMA9>EMA21')
    else:
        score -= 0.2; reasons.append('EMA9<EMA21')
    if rsi.iloc[latest] > 60:
        score += 0.2; reasons.append('RSI>60')
    if rsi.iloc[latest] < 40:
        score -= 0.2; reasons.append('RSI<40')
    conf = min(max((score+0.5),0.0),1.0)
    signal = 'NO_TRADE' if conf<=0.62 else ('BUY' if score>0 else 'SELL')
    return signal, round(conf,3), reasons

def process_signals_for_pair(pair, timeframe):
    try:
        cur = conn.cursor()
        rows = cur.execute('SELECT ts,o,h,l,c,v FROM candles WHERE pair=? AND timeframe=? ORDER BY ts ASC', (pair, timeframe)).fetchall()
        if len(rows) < 40: return
        import pandas as pd
        df = pd.DataFrame(rows, columns=['ts','o','h','l','c','v'])
        sig, conf, reasons = compute_signal_from_candles(df)
        meta = {'sample': 'termux'}
        cur.execute('INSERT INTO signals (pair,timeframe,ts,signal,confidence,reasons,metadata,created_at) VALUES (?,?,?,?,?,?,?,?)',
                    (pair, timeframe, datetime.utcnow().isoformat(), sig, conf, json.dumps(reasons), json.dumps(meta), datetime.utcnow().isoformat()))
        conn.commit()
        from notifier import send_signal_nonblocking
        try:
            send_signal_nonblocking({'pair':pair,'timeframe':timeframe,'signal':sig,'confidence':conf,'reasons':reasons})
        except Exception as e:
            print('notify err', e)
    except Exception as e:
        print('proc err', e)

@app.get('/signals/latest')
def latest(limit: int = 20):
    cur = conn.cursor()
    rows = cur.execute('SELECT pair,timeframe,ts,signal,confidence,reasons,metadata,created_at FROM signals ORDER BY created_at DESC LIMIT ?', (limit,)).fetchall()
    out = []
    for r in rows:
        out.append({'pair': r[0], 'timeframe': r[1], 'ts': r[2], 'signal': r[3], 'confidence': r[4], 'reasons': json.loads(r[5]) if r[5] else [], 'metadata': json.loads(r[6]) if r[6] else {}, 'created_at': r[7]})
    return out

@app.get('/api/health')
def health():
    return {'status':'ok'}