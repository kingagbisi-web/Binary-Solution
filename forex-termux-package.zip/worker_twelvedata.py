import os, time, requests, json
from datetime import datetime
from dotenv import load_dotenv
load_dotenv()
APIKEY = os.getenv('TWELVEDATA_APIKEY','')
PAIRS = os.getenv('PAIRS','EUR/USD').split(',')
TIMEFRAMES = os.getenv('TIMEFRAMES','1min').split(',')
POST_URL = os.getenv('POST_URL','http://127.0.0.1:8000/ingest/candle')

def td_symbol_try_variants(sym):
    s = sym.strip()
    candidates = [s, s.replace('/',''), s.replace('/','-'), s.replace('/','_')]
    seen = []
    for c in candidates:
        if c not in seen:
            seen.append(c)
    return seen

def fetch_latest(symbol, interval):
    for cand in td_symbol_try_variants(symbol):
        params = {'symbol': cand, 'interval': interval, 'apikey': APIKEY, 'outputsize': 2, 'format':'JSON'}
        try:
            r = requests.get('https://api.twelvedata.com/time_series', params=params, timeout=10)
            if r.status_code != 200: continue
            j = r.json()
            if 'values' in j and isinstance(j['values'], list) and len(j['values'])>0:
                return j['values'][0]
        except Exception as e:
            print('td err', e)
    return None

def post_local(candle, pair, timeframe):
    payload = {'pair': pair, 'timeframe': timeframe, 'ts': candle.get('datetime') or candle.get('datetime'), 'o': float(candle.get('open',0)), 'h': float(candle.get('high',0)), 'l': float(candle.get('low',0)), 'c': float(candle.get('close',0)), 'v': float(candle.get('volume',0))}
    try:
        requests.post(POST_URL, json=payload, timeout=5)
    except Exception as e:
        print('post err', e)

if __name__ == '__main__':
    if not APIKEY:
        print('No TwelveData key, exiting.')
        exit(0)
    while True:
        for p in PAIRS:
            for tf in TIMEFRAMES:
                try:
                    latest = fetch_latest(p, tf)
                    if latest:
                        post_local(latest, p, tf)
                except Exception as e:
                    print('err', e)
        time.sleep(15)