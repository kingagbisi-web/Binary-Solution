import os, threading, requests
from dotenv import load_dotenv
load_dotenv()
BOT = os.getenv('TELEGRAM_BOT_TOKEN','').strip()
CHAT = os.getenv('TELEGRAM_CHAT_ID','').strip()

def send_telegram_message(text):
    if not BOT or not CHAT:
        return False
    url = f"https://api.telegram.org/bot{BOT}/sendMessage"
    payload = {'chat_id': CHAT, 'text': text, 'parse_mode':'HTML'}
    try:
        r = requests.post(url, data=payload, timeout=5)
        return r.status_code == 200
    except Exception as e:
        print('telegram err', e); return False

def format_signal_message(sig):
    pair = sig.get('pair'); tf = sig.get('timeframe'); s = sig.get('signal'); conf = sig.get('confidence'); reasons = ', '.join(sig.get('reasons',[]))
    txt = f"🔔 <b>Signal</b>\nPair: {pair}\nTimeframe: {tf}\nAction: {s}\nConfidence: {conf}\nReasons: {reasons}"
    return txt

def send_signal_nonblocking(sig):
    text = format_signal_message(sig)
    t = threading.Thread(target=send_telegram_message, args=(text,))
    t.daemon = True; t.start()
    return True