# Gozie-FX-Binary-
FX Binary solution 
