from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.utils import get_color_from_hex
from dotenv import load_dotenv
import os, requests, threading, random, time, json

load_dotenv()

KV = '''
BoxLayout:
    orientation: 'vertical'
    spacing: 8
    padding: 12
    BoxLayout:
        size_hint_y: None
        height: '48dp'
        Label:
            text: app.title
            bold: True
            font_size: '18sp'
        Spinner:
            id: theme_spinner
            text: 'Blue'
            values: app.theme_names
            size_hint_x: None
            width: '140dp'
            on_text: app.set_theme(self.text)
    BoxLayout:
        size_hint_y: None
        height: '48dp'
        Label:
            text: 'Mode:'
            size_hint_x: None
            width: '60dp'
        Spinner:
            id: mode_spinner
            text: app.mode
            values: ['Backend','Demo']
            size_hint_x: None
            width: '140dp'
            on_text: app.set_mode(self.text)
        Label:
            text: 'Timeframe:'
            size_hint_x: None
            width: '90dp'
        Spinner:
            id: tf_spinner
            text: app.timeframe
            values: app.timeframes
            size_hint_x: None
            width: '120dp'
            on_text: app.on_timeframe(self.text)
    BoxLayout:
        size_hint_y: None
        height: '40dp'
        TextInput:
            id: pairs_input
            text: app.pairs
            multiline: False
            hint_text: 'Comma-separated pairs'
            on_text_validate: app.on_pairs(self.text)
        Button:
            text: 'Refresh'
            size_hint_x: None
            width: '120dp'
            on_release: app.fetch_signals()
    RecycleView:
        id: rv
        viewclass: 'SignalRow'
        RecycleBoxLayout:
            default_size: None, dp(64)
            default_size_hint: 1, None
            size_hint_y: None
            height: self.minimum_height
            orientation: 'vertical'

<SignalRow@BoxLayout>:
    orientation: 'horizontal'
    size_hint_y: None
    height: '64dp'
    padding: 8
    spacing: 8
    canvas.before:
        Color:
            rgba: root.bgcolor if hasattr(root, 'bgcolor') else (1,1,1,1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [8,]
    Label:
        text: root.pair if hasattr(root, 'pair') else ''
        size_hint_x: 0.28
    Label:
        text: root.timeframe if hasattr(root, 'timeframe') else ''
        size_hint_x: 0.18
    Label:
        text: root.signal if hasattr(root, 'signal') else ''
        size_hint_x: 0.28
    Label:
        text: str(root.confidence) if hasattr(root, 'confidence') else ''
        size_hint_x: 0.12
    Button:
        text: 'Details'
        size_hint_x: 0.14
        on_release: app.show_details(root)
''' )

class GozieApp(App):
    title = "Gozie FX Binary"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.api_base = os.getenv('API_BASE','http://127.0.0.1:8000')
        self.timeframes = os.getenv('TIMEFRAMES','1min,5min,15min,1h').split(',')
        self.timeframe = self.timeframes[0]
        self.pairs = os.getenv('PAIRS','EUR/USD,GBP/USD,USD/JPY').strip()
        self.poll_interval = int(os.getenv('POLL_SECONDS','10'))
        self.mode = os.getenv('APP_MODE','Demo')  # 'Backend' or 'Demo'
        self._event = None
        self.theme_names = ['Blue','Gray','Pink','Yellow','Red','Green','Brown']
        self.theme_map = {
            'Blue': '#1e88e5',
            'Gray': '#607d8b',
            'Pink': '#e91e63',
            'Yellow': '#ffca28',
            'Red': '#e53935',
            'Green': '#43a047',
            'Brown': '#6d4c41'
        }

    def build(self):
        self.root = Builder.load_string(KV)
        self.set_theme('Blue')  # default
        return self.root

    def on_start(self):
        Clock.schedule_once(lambda dt: self.fetch_signals(), 1)

    def set_theme(self, name):
        color = get_color_from_hex(self.theme_map.get(name,'#1e88e5')) + [1]
        # update background color for items by storing in app
        self.current_bg = color

    def set_mode(self, m):
        self.mode = m

    def on_timeframe(self, tf):
        self.timeframe = tf
        self.fetch_signals()

    def on_pairs(self, txt):
        self.pairs = txt

    def start_auto(self):
        if self._event is None:
            self._event = Clock.schedule_interval(lambda dt: self.fetch_signals(), self.poll_interval)

    def stop_auto(self):
        if self._event:
            self._event.cancel(); self._event = None

    def fetch_signals(self):
        if self.mode == 'Demo':
            data = self.generate_demo_signals()
            self.update_list(data)
        else:
            def _fetch():
                try:
                    url = f"{self.api_base}/signals/latest"
                    r = requests.get(url, timeout=6)
                    if r.status_code==200:
                        data = r.json()
                        Clock.schedule_once(lambda dt: self.update_list(data))
                except Exception as e:
                    print('fetch err', e)
            threading.Thread(target=_fetch, daemon=True).start()

    def update_list(self, data):
        rv = self.root.ids.rv
        items = []
        for s in data:
            bgcolor = self.current_bg if hasattr(self,'current_bg') else [1,1,1,1]
            items.append({'pair':s.get('pair',''), 'timeframe':s.get('timeframe',''), 'signal':s.get('signal',''), 'confidence':s.get('confidence',0), 'bgcolor':bgcolor})
            if s.get('confidence',0) >= 0.75:
                self.show_popup(s)
        rv.data = items

    def show_popup(self, s):
        txt = f"{s.get('pair')} — {s.get('timeframe')}\n{ s.get('signal')} ({s.get('confidence')})"
        popup = Popup(title='Signal', content=Label(text=txt), size_hint=(0.8,0.35))
        popup.open()

    def show_details(self, row):
        # show a simple details popup
        txt = json.dumps({'pair':row.pair,'timeframe':row.timeframe,'signal':row.signal,'confidence':row.confidence}, indent=2)
        popup = Popup(title='Signal Details', content=Label(text=txt), size_hint=(0.9,0.6))
        popup.open()

    def generate_demo_signals(self):
        pairs = [p.strip() for p in self.pairs.split(',') if p.strip()]
        out = []
        for p in pairs:
            s = random.choice(['BUY','SELL','NO_TRADE'])
            conf = round(random.random()*0.6 + (0.4 if s!='NO_TRADE' else 0.0),3)
            out.append({'pair':p,'timeframe':self.timeframe,'signal':s,'confidence':conf})
        return out

if __name__ == '__main__':
    GozieApp().run()
