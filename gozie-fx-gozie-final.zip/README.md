Gozie FX Binary - Android App (Kivy)

This package is ready to build on GitHub Actions (free runner) or locally using Buildozer.


Steps to build using GitHub Actions (recommended - easiest):

1) Create a new GitHub repository and push the contents of this folder as the repo root.

2) Add the workflow file included (or let me add it) to .github/workflows/android-build.yml.

3) In GitHub Settings -> Actions -> Secrets, add the following secrets (if you plan to sign a release):
   - ANDROID_KEYSTORE_BASE64: (base64-encoded keystore file)
   - ANDROID_KEYSTORE_PASSWORD
   - ANDROID_KEY_ALIAS
   - ANDROID_KEY_PASSWORD

4) Run the workflow from the Actions tab or push to main.

Notes:
- The workflow attempts to install necessary Android SDK components. If the runner lacks some packages, I will refine the workflow.
- For a Play Store release, provide a keystore and add secrets to GitHub as above. The workflow can then produce a signed release APK.
