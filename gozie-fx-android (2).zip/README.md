Gozie FX Binary key - Android app

See main.py and buildozer.spec
